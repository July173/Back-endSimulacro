﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entity.Dtos.UserDTO
{
    public class AssignUserRolDto
    {
        public int UserId { get; set; }
        public int RolId { get; set; }
    }

}
